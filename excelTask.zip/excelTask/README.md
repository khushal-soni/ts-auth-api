## IMPORTANT LINKS

1. https://www.npmjs.com/package/xlsx#dates
2. https://github.com/CotalkerPartners/mongo-xlsx
3. https://github.com/SheetJS/sheetjs/issues/270
4. https://www.youtube.com/watch?v=tKz_ryychBY
